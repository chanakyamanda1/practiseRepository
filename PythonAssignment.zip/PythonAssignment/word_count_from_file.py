import os


def count_word_lengths_from_file(file):
    # Create an empty dictionary to store the outputresults
    outputresults = {}

    # Open the file for reading
    with open(file, 'r') as f:
        # Iterate over each eachline in the file
        for i, eachline in enumerate(f, 1):
            # Strip leading and trailing whitespace from the eachline
            eachline = eachline.strip()

            # Split the eachline into words
            words = eachline.split()

            # Create a dictionary to store the counts for this eachline
            counts = {}

            # Iterate over each word in the eachline
            for word in words:
                # Get the length of the word
                length = len(word)

                # If the length is not already in the counts dictionary, add it with a count of 1
                if length not in counts:
                    counts[length] = 1
                # Otherwise, increment the count for this length
                else:
                    counts[length] += 1

            # Add the counts dictionary to the outputresults dictionary
            outputresults[i] = counts

    return outputresults


# Test the function with a sample file
file = 'file.txt'
print(count_word_lengths_from_file(file))

def anagrams_palindromes(StringInputs):
    def is_anagram_palindrome(word):
        each_counts = {}
        for char in word:
            each_counts[char] = each_counts.get(char, 0) + 1
        odd_count = [count for count in each_counts.values() if count %2 == 1]
        return len(odd_count) <= 1
    return [word for word in StringInputs if is_anagram_palindrome(word)]


StringInputs = ['racecar', 'hello', 'level', 'carcare',
         'carecar', 'civic', 'lehol', 'vicic']
result = anagrams_palindromes(StringInputs)
print(result)

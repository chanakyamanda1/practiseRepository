import time


def execution_time(func):
    def wrapper(*args, **kwargs):
        first_execution_time = time.time()
        result = func(*args, **kwargs)
        last_execution_time = time.time()
        execution_time = last_execution_time - first_execution_time

        with open('execution_times.log', 'a') as f:
            f.write(f'{func.__name__}: {execution_time}\n')

        return result
    return wrapper


@execution_time
def test_function():
    time.sleep(1)

# sample function to test time of execution


@execution_time
def multiply_two(a, b):
    return a * b


print(multiply_two(100, 4))


test_function()

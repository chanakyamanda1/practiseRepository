def sort_by_length(inputstrings): return sorted(inputstrings, key=lambda s: -len(s))


# test data for the function
inputstrings = ["dog", "cat", "bird"]
print(sort_by_length(inputstrings))  # ['bird', 'cat', 'dog']

inputstrings = ["python", "java", "c++"]
print(sort_by_length(inputstrings))  # ["python", "java", "c++"]




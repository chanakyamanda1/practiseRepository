def value_error_input():
    while True:
        try:
            return int(input("Enter an integer: "))
        except ValueError:
            print("ValueError exception handled, new input prompted")


# Test the function
x = value_error_input()
print(x)  # prints the input value enterd by the user.
